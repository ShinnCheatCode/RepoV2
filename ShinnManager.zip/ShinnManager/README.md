# Shinn Manager (app cá nhân)

## Build IPA (không cần Mac)
1. Tạo repo GitHub **private**, upload toàn bộ thư mục này.
2. Tab **Actions** → **Build IPA** → **Run workflow**.
3. Xong tải artifact `ShinnManager-ipa` → giải nén lấy `ShinnManager.ipa`.
4. Cài lên iPhone bằng Sideloadly / AltStore / TrollStore.

## Cấu hình server (VPS)
Thêm biến môi trường cho **main.py** (key server):
- `ADMIN_TOKEN`  (có sẵn)
- `BOT_TOKEN`  (token bot, chỉ để gửi tin xác nhận đăng nhập)
- `APP_ALLOWED_IDS=8987709740,6669144064`

Cho **bot.py**:
- `BOT_TOKEN`, `KEY_API_ADMIN_TOKEN` (= ADMIN_TOKEN), `KEY_API_URL`
- `APP_ALLOWED_IDS=8987709740,6669144064`

Cả 2 tài khoản Telegram phải bấm **Start** với bot.
Nên đặt server sau HTTPS (nginx / Cloudflare Tunnel) vì app gửi token phiên qua mạng.
