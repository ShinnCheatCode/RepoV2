import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:local_auth/local_auth.dart';

const _storage = FlutterSecureStorage();

// ───────────────────────── API ─────────────────────────
class ApiError implements Exception {
  final int code;
  final String msg;
  ApiError(this.code, this.msg);
  @override
  String toString() => msg;
}

class Api {
  final String base;
  final String? token;
  Api(this.base, this.token);

  Map<String, String> get _h => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<dynamic> call(String method, String path, [Object? body]) async {
    final uri = Uri.parse('$base$path');
    const t = Duration(seconds: 15);
    http.Response r;
    try {
      if (method == 'GET') {
        r = await http.get(uri, headers: _h).timeout(t);
      } else if (method == 'DELETE') {
        r = await http.delete(uri, headers: _h).timeout(t);
      } else {
        r = await http.post(uri, headers: _h, body: jsonEncode(body ?? {})).timeout(t);
      }
    } on TimeoutException {
      throw ApiError(0, 'Server không phản hồi (hết thời gian chờ)');
    } catch (_) {
      throw ApiError(0, 'Không kết nối được server');
    }
    if (r.statusCode >= 400) {
      String m = 'Lỗi ${r.statusCode}';
      try {
        final d = jsonDecode(utf8.decode(r.bodyBytes));
        if (d is Map && d['detail'] != null) m = '${d['detail']}';
      } catch (_) {}
      if (r.statusCode == 401 && token != null) onUnauthorized?.call();
      if (r.statusCode == 429) m = 'Thao tác quá nhanh, thử lại sau';
      throw ApiError(r.statusCode, m);
    }
    return r.body.isEmpty ? null : jsonDecode(utf8.decode(r.bodyBytes));
  }
}

VoidCallback? onUnauthorized;

// ───────────────────────── Helpers ─────────────────────────
String fmtExpire(String? iso) {
  if (iso == null) return '?';
  final d = DateTime.tryParse(iso);
  if (d == null) return iso;
  if (d.year >= 2099) return 'Vĩnh viễn';
  final diff = d.difference(DateTime.now());
  if (diff.isNegative) return 'Hết hạn';
  if (diff.inDays >= 1) return 'Còn ${diff.inDays} ngày ${diff.inHours % 24} giờ';
  if (diff.inHours >= 1) return 'Còn ${diff.inHours} giờ ${diff.inMinutes % 60} phút';
  return 'Còn ${diff.inMinutes} phút';
}

void toast(BuildContext c, String m, {bool error = false}) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(
    content: Text(m),
    backgroundColor: error ? Colors.red.shade800 : null,
  ));
}

Future<bool> confirm(BuildContext c, String text) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      content: Text(text),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Huỷ')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Đồng ý')),
      ],
    ),
  );
  return r == true;
}

// ───────────────────────── App ─────────────────────────
void main() => runApp(const ShinnApp());

class ShinnApp extends StatelessWidget {
  const ShinnApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Shinn Manager',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorSchemeSeed: const Color(0xFF7C4DFF),
        ),
        home: const Root(),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  Api? api;
  String? savedUrl;
  bool booting = true;
  bool locked = false;

  @override
  void initState() {
    super.initState();
    onUnauthorized = _logout;
    _boot();
  }

  Future<bool> _faceId() async {
    try {
      final la = LocalAuthentication();
      if (!await la.isDeviceSupported()) return true;
      return await la.authenticate(localizedReason: 'Mở app quản lý');
    } catch (_) {
      return false;
    }
  }

  Future<void> _boot() async {
    final url = await _storage.read(key: 'url');
    final tok = await _storage.read(key: 'token');
    savedUrl = url;
    if (url != null && tok != null) {
      final ok = await _faceId();
      setState(() {
        booting = false;
        if (ok) {
          api = Api(url, tok);
        } else {
          locked = true;
        }
      });
    } else {
      setState(() => booting = false);
    }
  }

  Future<void> _logout() async {
    final a = api;
    try {
      await a?.call('POST', '/mgr/logout');
    } catch (_) {}
    await _storage.delete(key: 'token');
    if (mounted) setState(() => api = null);
  }

  @override
  Widget build(BuildContext context) {
    if (booting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (locked) {
      return Scaffold(
        body: Center(
          child: FilledButton.icon(
            icon: const Icon(Icons.lock),
            label: const Text('Mở khoá bằng Face ID'),
            onPressed: () {
              setState(() => booting = true);
              _boot();
            },
          ),
        ),
      );
    }
    if (api == null) {
      return LoginPage(
        initialUrl: savedUrl ?? '',
        onLogin: (a) => setState(() => api = a),
      );
    }
    return Home(api: api!, onLogout: _logout);
  }
}

// ───────────────────────── Login ─────────────────────────
class LoginPage extends StatefulWidget {
  final String initialUrl;
  final void Function(Api) onLogin;
  const LoginPage({super.key, required this.initialUrl, required this.onLogin});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late final TextEditingController url = TextEditingController(text: widget.initialUrl);
  final tg = TextEditingController();
  bool busy = false;
  bool waiting = false;
  bool cancelled = false;
  String? error;

  @override
  void dispose() {
    cancelled = true;
    super.dispose();
  }

  String _norm(String s) {
    s = s.trim();
    while (s.endsWith('/')) {
      s = s.substring(0, s.length - 1);
    }
    if (s.isNotEmpty && !s.startsWith('http')) s = 'https://$s';
    return s;
  }

  Future<void> _start() async {
    final base = _norm(url.text);
    final id = int.tryParse(tg.text.trim());
    if (base.isEmpty || id == null) {
      setState(() => error = 'Nhập địa chỉ server và ID Telegram (chỉ số).');
      return;
    }
    setState(() {
      busy = true;
      error = null;
    });
    cancelled = false;
    final api = Api(base, null);
    try {
      final r = await api.call('POST', '/mgr/login/request', {'tg_id': id, 'device': 'iPhone (app Shinn Manager)'});
      final reqId = r['req_id'];
      final ttl = (r['ttl'] ?? 120) as int;
      if (mounted) setState(() => waiting = true);
      final end = DateTime.now().add(Duration(seconds: ttl));
      while (mounted && !cancelled && DateTime.now().isBefore(end)) {
        await Future.delayed(const Duration(seconds: 3));
        if (!mounted || cancelled) return;
        final s = await api.call('GET', '/mgr/login/status/$reqId');
        final st = s['status'];
        if (st == 'approved') {
          await _storage.write(key: 'url', value: base);
          await _storage.write(key: 'token', value: s['token']);
          widget.onLogin(Api(base, s['token']));
          return;
        }
        if (st == 'denied') {
          setState(() => error = 'Bạn đã từ chối đăng nhập.');
          break;
        }
        if (st == 'expired') break;
      }
      if (mounted && error == null) {
        setState(() => error = 'Hết thời gian hoặc ID không hợp lệ. Hãy kiểm tra Telegram rồi thử lại.');
      }
    } on ApiError catch (e) {
      if (mounted) setState(() => error = e.msg);
    } finally {
      if (mounted) {
        setState(() {
          busy = false;
          waiting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.shield_moon, size: 72),
                const SizedBox(height: 12),
                const Text('Shinn Manager', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                const SizedBox(height: 28),
                TextField(
                  controller: url,
                  enabled: !busy,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(labelText: 'Địa chỉ server', hintText: 'https://domain-cua-ban', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: tg,
                  enabled: !busy,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'ID Telegram', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 18),
                if (waiting)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 12),
                        Text('Mở Telegram và bấm ✅ Xác nhận trong tin nhắn của bot…', textAlign: TextAlign.center),
                      ]),
                    ),
                  )
                else
                  FilledButton(
                    onPressed: busy ? null : _start,
                    child: const Padding(padding: EdgeInsets.all(12), child: Text('Gửi yêu cầu xác nhận')),
                  ),
                if (error != null) ...[
                  const SizedBox(height: 14),
                  Text(error!, textAlign: TextAlign.center, style: TextStyle(color: Colors.red.shade300)),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── Home ─────────────────────────
class Home extends StatefulWidget {
  final Api api;
  final Future<void> Function() onLogout;
  const Home({super.key, required this.api, required this.onLogout});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tab == 0 ? 'Quản lý key' : 'Điều khiển bot'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Đăng xuất',
            onPressed: () async {
              if (await confirm(context, 'Đăng xuất khỏi app?')) widget.onLogout();
            },
          ),
        ],
      ),
      body: IndexedStack(index: tab, children: [
        KeysTab(api: widget.api),
        BotTab(api: widget.api),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.vpn_key), label: 'Key'),
          NavigationDestination(icon: Icon(Icons.smart_toy), label: 'Bot'),
        ],
      ),
    );
  }
}

// ───────────────────────── Keys ─────────────────────────
const _durations = <String, int>{
  'test (1 giờ)': 3600,
  '1 ngày': 86400,
  '3 ngày': 3 * 86400,
  '7 ngày': 7 * 86400,
  '15 ngày': 15 * 86400,
  '30 ngày': 30 * 86400,
  'Vĩnh viễn': 86400,
};

class KeysTab extends StatefulWidget {
  final Api api;
  const KeysTab({super.key, required this.api});
  @override
  State<KeysTab> createState() => _KeysTabState();
}

class _KeysTabState extends State<KeysTab> {
  List<dynamic> keys = [];
  Map<String, dynamic>? stats;
  bool loading = true;
  String? err;
  String q = '';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      err = null;
    });
    try {
      final k = await widget.api.call('GET', '/mgr/keys?limit=200');
      final s = await widget.api.call('GET', '/mgr/stats');
      if (!mounted) return;
      setState(() {
        keys = k as List<dynamic>;
        stats = Map<String, dynamic>.from(s);
        loading = false;
      });
    } on ApiError catch (e) {
      if (mounted) {
        setState(() {
          err = e.msg;
          loading = false;
        });
      }
    }
  }

  Future<void> _do(Future<dynamic> Function() f, String okMsg) async {
    try {
      await f();
      if (mounted) toast(context, okMsg);
      await load();
    } on ApiError catch (e) {
      if (mounted) toast(context, e.msg, error: true);
    }
  }

  void _actions(Map k) {
    final key = k['key'] as String;
    final isLocked = (k['locked'] ?? 0) == 1;
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(title: SelectableText(key), subtitle: Text('${k['label'] ?? ''} · ${fmtExpire(k['expires_at'])}')),
          ListTile(
            leading: const Icon(Icons.copy),
            title: const Text('Sao chép key'),
            onTap: () {
              Clipboard.setData(ClipboardData(text: key));
              Navigator.pop(context);
              toast(context, 'Đã sao chép');
            },
          ),
          ListTile(
            leading: const Icon(Icons.devices),
            title: const Text('Reset thiết bị'),
            onTap: () {
              Navigator.pop(context);
              _do(() => widget.api.call('POST', '/mgr/keys/$key/reset-devices'), 'Đã reset thiết bị');
            },
          ),
          ListTile(
            leading: Icon(isLocked ? Icons.lock_open : Icons.lock),
            title: Text(isLocked ? 'Mở khoá key' : 'Khoá key'),
            onTap: () {
              Navigator.pop(context);
              _do(() => widget.api.call('POST', '/mgr/keys/$key/${isLocked ? 'unlock' : 'lock'}'),
                  isLocked ? 'Đã mở khoá' : 'Đã khoá');
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete, color: Colors.redAccent),
            title: const Text('Xoá key', style: TextStyle(color: Colors.redAccent)),
            onTap: () async {
              Navigator.pop(context);
              if (await confirm(context, 'Xoá key $key?')) {
                _do(() => widget.api.call('DELETE', '/mgr/keys/$key'), 'Đã xoá');
              }
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _create() async {
    String dur = _durations.keys.first;
    int qty = 1;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Tạo key'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButton<String>(
              isExpanded: true,
              value: dur,
              items: _durations.keys.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (v) => set(() => dur = v!),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Số lượng'),
              Row(children: [
                IconButton(onPressed: qty > 1 ? () => set(() => qty--) : null, icon: const Icon(Icons.remove)),
                Text('$qty', style: const TextStyle(fontSize: 18)),
                IconButton(onPressed: qty < 50 ? () => set(() => qty++) : null, icon: const Icon(Icons.add)),
              ]),
            ]),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Huỷ')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Tạo')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final isTest = dur.startsWith('test');
    final perm = dur == 'Vĩnh viễn';
    try {
      final res = await widget.api.call('POST', '/mgr/keys', {
        'label': isTest ? 'test' : (perm ? 'permanent' : dur),
        'kind': isTest ? 'test' : 'vip',
        'seconds': _durations[dur],
        'quantity': qty,
        'permanent': perm,
      }) as List<dynamic>;
      final text = res.map((e) => e['key']).join('\n');
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Đã tạo ${res.length} key'),
          content: SelectableText(text),
          actions: [
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: text));
                toast(ctx, 'Đã sao chép');
              },
              child: const Text('Sao chép'),
            ),
            FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Đóng')),
          ],
        ),
      );
      load();
    } on ApiError catch (e) {
      if (mounted) toast(context, e.msg, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final shown = keys.where((k) => q.isEmpty || '${k['key']}'.toLowerCase().contains(q.toLowerCase())).toList();
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(onPressed: _create, icon: const Icon(Icons.add), label: const Text('Tạo key')),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
          children: [
            if (stats != null)
              Row(children: [
                _stat('Tổng', stats!['total']),
                _stat('Đã dùng', stats!['used']),
                _stat('Hết hạn', stats!['expired']),
              ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Tìm key', isDense: true, border: OutlineInputBorder()),
                  onChanged: (v) => setState(() => q = v),
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (v) async {
                  final lock = v == 'lock';
                  if (await confirm(context, lock ? 'Khoá TẤT CẢ key (trừ key owner)?' : 'Mở khoá tất cả key?')) {
                    _do(() => widget.api.call('POST', lock ? '/mgr/keys-lock-all' : '/mgr/keys-unlock-all'),
                        lock ? 'Đã khoá tất cả' : 'Đã mở khoá tất cả');
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'lock', child: Text('Khoá tất cả key')),
                  PopupMenuItem(value: 'unlock', child: Text('Mở khoá tất cả key')),
                ],
              ),
            ]),
            if (loading) const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator())),
            if (err != null) Padding(padding: const EdgeInsets.all(20), child: Text(err!, style: TextStyle(color: Colors.red.shade300))),
            for (final k in shown)
              Card(
                child: ListTile(
                  onTap: () => _actions(k as Map),
                  leading: Icon((k['locked'] ?? 0) == 1 ? Icons.lock : Icons.vpn_key, color: k['role'] == 'admin' ? Colors.amber : null),
                  title: Text('${k['key']}', style: const TextStyle(fontFamily: 'Menlo', fontSize: 13)),
                  subtitle: Text('${k['label'] ?? k['kind']} · ${fmtExpire(k['expires_at'])}'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String l, dynamic v) => Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(children: [
              Text('$v', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text(l, style: const TextStyle(fontSize: 12)),
            ]),
          ),
        ),
      );
}

// ───────────────────────── Bot ─────────────────────────
class BotTab extends StatefulWidget {
  final Api api;
  const BotTab({super.key, required this.api});
  @override
  State<BotTab> createState() => _BotTabState();
}

class _BotTabState extends State<BotTab> {
  Map<String, dynamic> st = {};
  String? err;
  bool busy = false;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 6), (_) => load());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    try {
      final s = await widget.api.call('GET', '/mgr/bot/state');
      if (mounted) {
        setState(() {
          st = Map<String, dynamic>.from(s ?? {});
          err = null;
        });
      }
    } on ApiError catch (e) {
      if (mounted) setState(() => err = e.msg);
    }
  }

  Future<Map> runJob(String kind, Map<String, dynamic> payload) async {
    final r = await widget.api.call('POST', '/mgr/bot/job', {'kind': kind, 'payload': payload});
    final id = r['id'];
    for (var i = 0; i < 12; i++) {
      await Future.delayed(const Duration(seconds: 1));
      final j = await widget.api.call('GET', '/mgr/bot/job/$id');
      if (j['status'] == 'done') return (j['result'] ?? {}) as Map;
      if (j['status'] == 'failed') throw ApiError(0, '${(j['result'] ?? {})['error'] ?? 'Bot báo lỗi'}');
    }
    throw ApiError(0, 'Bot chưa phản hồi. Bot có đang chạy không?');
  }

  Future<void> _job(String kind, Map<String, dynamic> p, String okMsg) async {
    setState(() => busy = true);
    try {
      await runJob(kind, p);
      if (mounted) toast(context, okMsg);
      await load();
    } on ApiError catch (e) {
      if (mounted) toast(context, e.msg, error: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _points({String? uid}) async {
    final u = TextEditingController(text: uid ?? '');
    final d = TextEditingController();
    final n = TextEditingController();
    bool notify = true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Cộng / trừ điểm'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: u, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ID Telegram người nhận')),
              TextField(
                controller: d,
                keyboardType: const TextInputType.numberWithOptions(signed: true),
                decoration: const InputDecoration(labelText: 'Số điểm (âm = trừ)', hintText: '-10'),
              ),
              TextField(controller: n, decoration: const InputDecoration(labelText: 'Lý do (tuỳ chọn)')),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Nhắn thông báo cho họ'), value: notify, onChanged: (v) => set(() => notify = v)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Huỷ')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Thực hiện')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final uid2 = int.tryParse(u.text.trim());
    final delta = int.tryParse(d.text.trim());
    if (uid2 == null || delta == null || delta == 0) {
      if (mounted) toast(context, 'ID hoặc số điểm không hợp lệ', error: true);
      return;
    }
    await _job('points_add', {'user_id': uid2, 'delta': delta, 'note': n.text.trim(), 'notify': notify},
        delta > 0 ? 'Đã cộng $delta điểm' : 'Đã trừ ${-delta} điểm');
  }

  Future<void> _message() async {
    final c = TextEditingController();
    final t = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Gửi tin nhắn'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(signed: true), decoration: const InputDecoration(labelText: 'ID người nhận (để trống = gửi vào nhóm)')),
            TextField(controller: t, maxLines: 4, decoration: const InputDecoration(labelText: 'Nội dung')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Huỷ')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Gửi')),
        ],
      ),
    );
    if (ok != true || t.text.trim().isEmpty) return;
    final cid = int.tryParse(c.text.trim());
    if (c.text.trim().isEmpty) {
      await _job('broadcast_group', {'text': t.text.trim()}, 'Đã gửi vào nhóm');
    } else if (cid != null) {
      await _job('message', {'chat_id': cid, 'text': t.text.trim()}, 'Đã gửi tin');
    } else if (mounted) {
      toast(context, 'ID không hợp lệ', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final top = (st['top'] as List?) ?? [];
    final cmds = ((st['commands'] as List?) ?? []).cast<String>();
    final disabled = ((st['disabled'] as List?) ?? []).cast<String>();
    return Stack(children: [
      RefreshIndicator(
        onRefresh: load,
        child: ListView(padding: const EdgeInsets.all(12), children: [
          if (err != null) Text(err!, style: TextStyle(color: Colors.red.shade300)),
          if (st.isEmpty && err == null)
            const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Chưa nhận được dữ liệu từ bot. Hãy chắc chắn bot đang chạy bản mới.'))),
          if (st.isNotEmpty)
            Card(
              child: ListTile(
                leading: const Icon(Icons.groups),
                title: Text('${st['members'] ?? 0} người có điểm'),
                subtitle: Text('BXH reset sau ${st['reset_days_left'] ?? '?'} ngày'),
              ),
            ),
          Wrap(spacing: 8, runSpacing: 8, children: [
            FilledButton.icon(onPressed: busy ? null : () => _points(), icon: const Icon(Icons.exposure), label: const Text('Cộng/trừ điểm')),
            FilledButton.tonalIcon(onPressed: busy ? null : _message, icon: const Icon(Icons.send), label: const Text('Gửi tin')),
            OutlinedButton.icon(
              onPressed: busy
                  ? null
                  : () async {
                      if (await confirm(context, 'Kết thúc tuần: phát key cho top 1-2-3 và xoá toàn bộ điểm?')) {
                        _job('reset_ranking', {}, 'Đã reset BXH và phát thưởng');
                      }
                    },
              icon: const Icon(Icons.emoji_events),
              label: const Text('Reset BXH + thưởng'),
            ),
          ]),
          const SizedBox(height: 16),
          const Text('🏆 BXH tuần', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          for (var i = 0; i < top.length; i++)
            Card(
              child: ListTile(
                dense: true,
                leading: CircleAvatar(radius: 14, child: Text('${i + 1}')),
                title: Text('${top[i]['name']}${(top[i]['username'] ?? '') != '' ? ' (@${top[i]['username']})' : ''}'),
                subtitle: Text('ID ${top[i]['id']}'),
                trailing: Text('${top[i]['points']} đ', style: const TextStyle(fontWeight: FontWeight.bold)),
                onTap: busy ? null : () => _points(uid: '${top[i]['id']}'),
              ),
            ),
          const SizedBox(height: 16),
          Row(children: [
            const Expanded(child: Text('⚙️ Lệnh của bot', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
            TextButton(onPressed: busy ? null : () => _job('lock_all_commands', {}, 'Đã khoá tất cả lệnh'), child: const Text('Khoá hết')),
            TextButton(onPressed: busy ? null : () => _job('unlock_all_commands', {}, 'Đã mở tất cả lệnh'), child: const Text('Mở hết')),
          ]),
          const Text('Bật = member dùng được. Owner luôn dùng được.', style: TextStyle(fontSize: 12)),
          for (final c in cmds)
            SwitchListTile(
              dense: true,
              title: Text('/$c'),
              value: !disabled.contains(c),
              onChanged: busy ? null : (v) => _job('lock_command', {'command': c, 'locked': !v}, v ? '/$c đã mở' : '/$c đã khoá'),
            ),
          const SizedBox(height: 40),
        ]),
      ),
      if (busy) const Positioned(top: 0, left: 0, right: 0, child: LinearProgressIndicator()),
    ]);
  }
}
